#!/bin/bash

database="gas"
row_count=100000
line_feed_sym="^"
out_file="/tmp/log.csv"

psql -c "\\c $database"  -c "\\copy (select * from (select id, edit_time, regexp_replace(message, E'[\\n\\r]+', '$line_feed_sym', 'g' ) mess  from public.logs order by id desc limit $row_count) f order by f.id) TO '$out_file' CSV ENCODING 'UTF8' QUOTE '\"' ESCAPE ';'"
